--
-- PostgreSQL database dump
--

\restrict CvDSDFXCjPR9QwcxC9hwdCPQDZb7GqUw5ag6nQCi4BHEbX0sfcx7ZFgSViGGjlg

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'VIP',
    'USER'
);


ALTER TYPE public.userrole OWNER TO "user";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO "user";

--
-- Name: gift_categories; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.gift_categories (
    id integer NOT NULL,
    name character varying NOT NULL,
    description text,
    icon character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.gift_categories OWNER TO "user";

--
-- Name: gift_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.gift_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gift_categories_id_seq OWNER TO "user";

--
-- Name: gift_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.gift_categories_id_seq OWNED BY public.gift_categories.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying NOT NULL,
    price double precision,
    image_url character varying,
    platform character varying NOT NULL,
    platform_url character varying NOT NULL,
    category_id integer,
    description text,
    crawl_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    brand character varying,
    material character varying,
    suitable_scenes json,
    tags json,
    suitable_gender character varying,
    suitable_age_range character varying,
    style character varying,
    rating double precision,
    sales_count integer,
    stock_status character varying
);


ALTER TABLE public.products OWNER TO "user";

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO "user";

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: ratings; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.ratings (
    id integer NOT NULL,
    product_id integer NOT NULL,
    overall_grade character varying NOT NULL,
    match_score double precision,
    quality_score double precision,
    price_score double precision,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.ratings OWNER TO "user";

--
-- Name: ratings_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.ratings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ratings_id_seq OWNER TO "user";

--
-- Name: ratings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.ratings_id_seq OWNED BY public.ratings.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    product_id integer NOT NULL,
    rating double precision,
    comment text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.reviews OWNER TO "user";

--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reviews_id_seq OWNER TO "user";

--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    username character varying NOT NULL,
    hashed_password character varying NOT NULL,
    role public.userrole NOT NULL,
    is_active character varying NOT NULL
);


ALTER TABLE public.users OWNER TO "user";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO "user";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: gift_categories id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.gift_categories ALTER COLUMN id SET DEFAULT nextval('public.gift_categories_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: ratings id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.ratings ALTER COLUMN id SET DEFAULT nextval('public.ratings_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.alembic_version (version_num) FROM stdin;
20251207144318
\.


--
-- Data for Name: gift_categories; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.gift_categories (id, name, description, icon, created_at, updated_at) FROM stdin;
1	通用礼品	通用礼品类礼品	\N	2025-12-03 17:09:58.214667+00	\N
2	生活好物	生活好物类礼品	\N	2025-12-03 17:09:58.220609+00	\N
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.products (id, name, price, image_url, platform, platform_url, category_id, description, crawl_at, created_at, updated_at, brand, material, suitable_scenes, tags, suitable_gender, suitable_age_range, style, rating, sales_count, stock_status) FROM stdin;
1	生日礼物相关商品1	506.63	https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=446251413	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2	生日礼物相关商品2	247.28	https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=966390398	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	生日礼物相关商品3	1922.38	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=616799442	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4	生日礼物相关商品4	170.06	https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=512646564	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5	生日礼物相关商品5	1148.27	https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=402368275	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	生日礼物相关商品6	1233.17	https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=818463047	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7	生日礼物相关商品7	1988.53	https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=692058222	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	生日礼物相关商品8	903.46	https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=742681268	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9	生日礼物相关商品9	1747.36	https://images.unsplash.com/photo-1572635196237-14b3f281fbaf?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=564746309	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
10	生日礼物相关商品10	923.89	https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=346626651	1	这是生日礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.220609+00	2025-12-03 17:09:58.220609+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
11	【小红书推荐】生日礼物精选1	104.1	https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/706719	2	小红书热门生日礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.237067+00	2025-12-03 17:09:58.237067+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
12	【小红书推荐】生日礼物精选2	346.03	https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/124384	2	小红书热门生日礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.237067+00	2025-12-03 17:09:58.237067+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
13	【小红书推荐】生日礼物精选3	249.45	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/822740	2	小红书热门生日礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.237067+00	2025-12-03 17:09:58.237067+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
14	【小红书推荐】生日礼物精选4	325.26	https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/723517	2	小红书热门生日礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.237067+00	2025-12-03 17:09:58.237067+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
15	【小红书推荐】生日礼物精选5	323.97	https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/182255	2	小红书热门生日礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.237067+00	2025-12-03 17:09:58.237067+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
16	【小红书推荐】生日礼物精选6	350.44	https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/890831	2	小红书热门生日礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.237067+00	2025-12-03 17:09:58.237067+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
17	【小红书推荐】生日礼物精选7	258.6	https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/289284	2	小红书热门生日礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.237067+00	2025-12-03 17:09:58.237067+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	【小红书推荐】生日礼物精选8	394.69	https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/240192	2	小红书热门生日礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.237067+00	2025-12-03 17:09:58.237067+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
19	情人节礼物相关商品1	1465.68	https://images.unsplash.com/photo-1572635196237-14b3f281fbaf?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=469728490	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
20	情人节礼物相关商品2	1462.83	https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=584615807	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
21	情人节礼物相关商品3	363.68	https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=791517289	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
22	情人节礼物相关商品4	1944.49	https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=865311057	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
23	情人节礼物相关商品5	747.31	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=687626143	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
24	情人节礼物相关商品6	870.12	https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=909229735	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
25	情人节礼物相关商品7	267.1	https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=495144973	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
26	情人节礼物相关商品8	358.65	https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=977285934	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
27	情人节礼物相关商品9	1749.69	https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=355337149	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
28	情人节礼物相关商品10	1954.12	https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=126533175	1	这是情人节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
29	【小红书推荐】情人节礼物精选1	479.31	https://images.unsplash.com/photo-1572635196237-14b3f281fbaf?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/674201	2	小红书热门情人节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
30	【小红书推荐】情人节礼物精选2	427.8	https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/184766	2	小红书热门情人节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
31	【小红书推荐】情人节礼物精选3	380.84	https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/698149	2	小红书热门情人节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
32	【小红书推荐】情人节礼物精选4	240.24	https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/676709	2	小红书热门情人节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
33	【小红书推荐】情人节礼物精选5	62.51	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/960009	2	小红书热门情人节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
34	【小红书推荐】情人节礼物精选6	31.79	https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/198792	2	小红书热门情人节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
35	【小红书推荐】情人节礼物精选7	204.47	https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/373476	2	小红书热门情人节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
36	【小红书推荐】情人节礼物精选8	100.63	https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/956214	2	小红书热门情人节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:58.747116+00	2025-12-03 17:09:58.747116+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
37	母亲节礼物相关商品1	1019.29	https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=949014032	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
38	母亲节礼物相关商品2	741.74	https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=168673352	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
39	母亲节礼物相关商品3	288.14	https://images.unsplash.com/photo-1572635196237-14b3f281fbaf?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=650507942	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
40	母亲节礼物相关商品4	1531.75	https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=754523350	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
41	母亲节礼物相关商品5	1527.12	https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=142455205	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
42	母亲节礼物相关商品6	1159.68	https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=241441440	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
43	母亲节礼物相关商品7	65.35	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=376007915	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
44	母亲节礼物相关商品8	1698.47	https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=467455398	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
45	母亲节礼物相关商品9	240.28	https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=902042255	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
46	母亲节礼物相关商品10	1733.05	https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=776678825	1	这是母亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
47	【小红书推荐】母亲节礼物精选1	385.91	https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/482028	2	小红书热门母亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
48	【小红书推荐】母亲节礼物精选2	195.59	https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/577495	2	小红书热门母亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
49	【小红书推荐】母亲节礼物精选3	48.75	https://images.unsplash.com/photo-1572635196237-14b3f281fbaf?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/798307	2	小红书热门母亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
50	【小红书推荐】母亲节礼物精选4	494.08	https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/623979	2	小红书热门母亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
51	【小红书推荐】母亲节礼物精选5	399.78	https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/161555	2	小红书热门母亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
52	【小红书推荐】母亲节礼物精选6	86.4	https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/669593	2	小红书热门母亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
53	【小红书推荐】母亲节礼物精选7	165.06	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/695706	2	小红书热门母亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
54	【小红书推荐】母亲节礼物精选8	45.04	https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/339078	2	小红书热门母亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.269838+00	2025-12-03 17:09:59.269838+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
55	父亲节礼物相关商品1	1615.16	https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=373862496	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
56	父亲节礼物相关商品2	1448.12	https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=264702171	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
57	父亲节礼物相关商品3	183.08	https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=967493042	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
58	父亲节礼物相关商品4	650.52	https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=757191888	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
59	父亲节礼物相关商品5	1895.87	https://images.unsplash.com/photo-1572635196237-14b3f281fbaf?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=881973628	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
60	父亲节礼物相关商品6	869.91	https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=992139030	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
61	父亲节礼物相关商品7	1230.93	https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=540537078	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
62	父亲节礼物相关商品8	1116	https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=409435165	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
63	父亲节礼物相关商品9	149.47	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=583970878	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
64	父亲节礼物相关商品10	333.65	https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=345819414	1	这是父亲节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
65	【小红书推荐】父亲节礼物精选1	234.14	https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/690004	2	小红书热门父亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
66	【小红书推荐】父亲节礼物精选2	171.23	https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/273081	2	小红书热门父亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
67	【小红书推荐】父亲节礼物精选3	97.34	https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/424698	2	小红书热门父亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
68	【小红书推荐】父亲节礼物精选4	75.93	https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/544600	2	小红书热门父亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
69	【小红书推荐】父亲节礼物精选5	471.13	https://images.unsplash.com/photo-1572635196237-14b3f281fbaf?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/985071	2	小红书热门父亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
70	【小红书推荐】父亲节礼物精选6	71.46	https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/465518	2	小红书热门父亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
71	【小红书推荐】父亲节礼物精选7	163.5	https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/254597	2	小红书热门父亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
72	【小红书推荐】父亲节礼物精选8	212.62	https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/187495	2	小红书热门父亲节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:09:59.790645+00	2025-12-03 17:09:59.790645+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
73	圣诞节礼物相关商品1	819.09	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=429338863	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
74	圣诞节礼物相关商品2	1725.33	https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=773213888	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
75	圣诞节礼物相关商品3	788.73	https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=594310721	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
76	圣诞节礼物相关商品4	454.97	https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=698728089	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
77	圣诞节礼物相关商品5	1551.34	https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=958946000	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
78	圣诞节礼物相关商品6	1565.12	https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=985317169	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
79	圣诞节礼物相关商品7	1114.89	https://images.unsplash.com/photo-1572635196237-14b3f281fbaf?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=668812209	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
80	圣诞节礼物相关商品8	959.63	https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=367166268	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
81	圣诞节礼物相关商品9	442.04	https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=361844484	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
82	圣诞节礼物相关商品10	605.61	https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop	taobao	https://item.taobao.com/item.htm?id=884524290	1	这是圣诞节礼物相关的优质商品，适合作为礼品赠送。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
83	【小红书推荐】圣诞节礼物精选1	56.54	https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/606775	2	小红书热门圣诞节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
84	【小红书推荐】圣诞节礼物精选2	35.65	https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/380718	2	小红书热门圣诞节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
85	【小红书推荐】圣诞节礼物精选3	98.6	https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/360986	2	小红书热门圣诞节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
86	【小红书推荐】圣诞节礼物精选4	430.54	https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/432497	2	小红书热门圣诞节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
87	【小红书推荐】圣诞节礼物精选5	471.94	https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/972108	2	小红书热门圣诞节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
88	【小红书推荐】圣诞节礼物精选6	278	https://images.unsplash.com/photo-1483985988355-763728e1935b?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/508168	2	小红书热门圣诞节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
89	【小红书推荐】圣诞节礼物精选7	431.56	https://images.unsplash.com/photo-1572635196237-14b3f281fbaf?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/196720	2	小红书热门圣诞节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
90	【小红书推荐】圣诞节礼物精选8	179.07	https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=400&h=400&fit=crop	xiaohongshu	https://www.xiaohongshu.com/explore/823795	2	小红书热门圣诞节礼物推荐，高颜值好物，适合送礼。	2025-12-03 17:10:00.313103+00	2025-12-03 17:10:00.313103+00	2025-12-03 17:21:18.351003+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: ratings; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.ratings (id, product_id, overall_grade, match_score, quality_score, price_score, reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.reviews (id, product_id, rating, comment, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.users (id, email, created_at, updated_at, username, hashed_password, role, is_active) FROM stdin;
1	admin@example.com	2025-12-07 03:53:46.085526+00	\N	admin	$2b$12$MJngdRY69iMxVcDXRzpLuOpgoHCqwXK4f6MsSFIpXQBlnrfMpCH.K	ADMIN	true
2	vip@example.com	2025-12-07 03:53:46.085526+00	\N	vip	$2b$12$jwJH2YcpYt/Whg5ytnDx/uolU/RjwiYmoqkBLDJESjfEk/exqZGQ6	VIP	true
3	test@example.com	2025-12-07 03:57:39.504198+00	\N	testuser	$2b$12$kBBcQNNPRlBosyJNBeuMt.5D12VywKOSQSasQPZFEOmXO1Ep1K4qO	USER	true
4	\N	2025-12-07 03:59:30.64421+00	\N	jiaxidai	$2b$12$AC70lUIDtPwDf/M/s0V3AeIc.kIQnM1VuyPV/c33TkxGCuamJGnPm	USER	true
\.


--
-- Name: gift_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.gift_categories_id_seq', 2, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.products_id_seq', 90, true);


--
-- Name: ratings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.ratings_id_seq', 1, false);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.reviews_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: gift_categories gift_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.gift_categories
    ADD CONSTRAINT gift_categories_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: ratings ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_pkey PRIMARY KEY (id);


--
-- Name: ratings ratings_product_id_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_product_id_key UNIQUE (product_id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_gift_categories_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_gift_categories_id ON public.gift_categories USING btree (id);


--
-- Name: ix_gift_categories_name; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_gift_categories_name ON public.gift_categories USING btree (name);


--
-- Name: ix_products_brand; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_products_brand ON public.products USING btree (brand);


--
-- Name: ix_products_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_products_id ON public.products USING btree (id);


--
-- Name: ix_products_name; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_products_name ON public.products USING btree (name);


--
-- Name: ix_products_style; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_products_style ON public.products USING btree (style);


--
-- Name: ix_ratings_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_ratings_id ON public.ratings USING btree (id);


--
-- Name: ix_reviews_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_reviews_id ON public.reviews USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.gift_categories(id);


--
-- Name: ratings ratings_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: reviews reviews_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- PostgreSQL database dump complete
--

\unrestrict CvDSDFXCjPR9QwcxC9hwdCPQDZb7GqUw5ag6nQCi4BHEbX0sfcx7ZFgSViGGjlg

